Python Environment Package Status helps in determining the package versions used and relative version/timeline to the latest/stable versions


